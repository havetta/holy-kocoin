import { reactive } from "vue"

export const statePanel = reactive({
  sidePanelOpened: false,
})
