// RUN using cmd:  "npm t"
import { mainRunSpot } from "./mainRunSpot.js";

(async () => {
  mainRunSpot();
})();
