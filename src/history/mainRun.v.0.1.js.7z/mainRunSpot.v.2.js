import WebSocket from "ws";
import BinanceApi from "node-binance-api";

import { balance, fetchTicker, openOrders, positions } from "./balance.js";
import { cancelOldOrders, createOrder, cancelOrder, createOrderStopPrice } from "./order.js";
import { getExchange, state, setInitialState } from "./store.js";
import { exchanges, fetchMarkets, kukoinZeroFees } from "./exchange.js";
import { log, table, sameline, warn, err, oneLine } from "./utils/logger.js";
import { twoDecimals, leftPad } from "./utils/formatter.js";

const mainRunSpot = async () => {

  // INIT CCXT
  await setInitialState();

  // const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${state.symbol.toLowerCase().replace("/", "")}@kline_1s`);
  // ws.on('message', function incoming(data) {
  //   const btc = JSON.parse(data);
  //   console.log(`\x1b[1m\x1b[33m`);
  //   console.table(btc)
  // });

  // GET PRICE OVER BINANCE WEBSOCKET
  const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${state.symbol.toLowerCase().replace("/", "")}@trade`);
  ws.on('message', function incoming(data) {
    const btc = JSON.parse(data);
    state.price = btc.p;
  });
  
  // INIT BINANCE LIB
  const binance = new BinanceApi().options({
    APIKEY: process.env.apiKey,
    APISECRET: process.env.secret
  });

  // binance.websockets.trades(['BTCUSDT', 'ETHUSDT'], (trades) => {
  //   let {e:eventType, E:eventTime, s:symbol, p:price, q:quantity, m:maker, a:tradeId} = trades;
  //   console.info(symbol+" trade update. price: "+price+", quantity: "+quantity+", maker: "+maker);
  // });

  while (1) {
    try
    {
      const [bal] = await Promise.all([balance()]);

      const price = state.price;
      if (state.lastPrice === 0)
        state.lastPrice = price;

      const freeBtc = bal?.free[`BTC`];
      const freeUsdt = bal?.free[`USDT`];
      const balanceStr = `BTC:${leftPad(freeBtc, 8)} USDT:${leftPad(freeUsdt, 8)}`;

      const btcToBuy = Math.trunc(freeUsdt / price * 10000) / 10000;

      if (state.buyPrice === 0)
      {
        state.buyPrice = price - 10;
        console.log(`\x1b[1m\x1b[31mRESET\x1b[32m buy\x1b[33m price\x1b[34m to\x1b[35m current\x1b[36m ${price}\x1b[0m`);
      }

      oneLine(`wait`, twoDecimals(state.lastPrice), twoDecimals(price), balanceStr);
      

      ///////////////////////////////////////////////////////////
      // CANCEL BUY ORDERS (every x seconds)
      cancelOldOrders();

      ///////////////////////////////////////////////////////////
      // BUY
      if (freeUsdt >= 10 && state.lastPrice - 1 > price) {
        const lowerPrice = price < state.lastPrice ? price : state.lastPrice;
        state.buyPrice = lowerPrice - 0.5;
        oneLine(`\x1b[42mBUY `, twoDecimals(state.buyPrice), twoDecimals(price), balanceStr + "\n");

        // const stopLossPrice = price - 300;//Math.trunc(price * 0.0006); // 0.06% = 20000 * 0.0006 = 12
        // const takeProfPrice = price + 300;//Math.trunc(price * 0.0001); // 0.01% = 20000 * 0.0001 = 2
        // await getExchange().createMarketBuyOrder(state.symbol, 0.0012);
  
        state.buyOrderCreated = true;
      }

      ///////////////////////////////////////////////////////////
      // CREATE STOP LOSS
      // if (freeBtc >= 0.002) {
      //   oneLine(`\x1b[4mSTOP`, state.buyPrice - 10, twoDecimals(price), balanceStr + "\n");
      //   await createOrderStopPrice("sell", 0.0012, state.buyPrice - 20, state.buyPrice - 10);
      // }

      ///////////////////////////////////////////////////////////
      // SELL
      if (freeBtc >= 0.002) {
        // if (state.buyPrice + 3 < price) {
          let higherPrice = price > state.lastPrice ? price : state.lastPrice;
          higherPrice = state.buyPrice + 0.5;
          oneLine(`\x1b[41mSELL`, twoDecimals(higherPrice), twoDecimals(price), balanceStr + "\n");

          // const orders = await getExchange().fetchOpenOrders(state.symbol);
          // const sells = orders.filter(i => i.symbol === state.symbol && i.side === "sell");
          // for (let i in sells) {
          //   await cancelOrder(sells[i].id);
          // }
          // await createOrder("sell", 0.0012, higherPrice);
        // }
      }

      ///////////////////////////////////////////////////////////
      // Memorize last price
      state.lastPrice = price;
    }
    catch(e) {
      err(e?.message);
      // warn(e?.stack);
    }

    await new Promise(resolve => setTimeout(resolve, 100));
  }
}

export { mainRunSpot };
